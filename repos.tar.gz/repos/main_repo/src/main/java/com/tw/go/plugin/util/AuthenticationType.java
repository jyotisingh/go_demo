package com.tw.go.plugin.util;

public enum AuthenticationType {
    BASIC, DIGEST
}
