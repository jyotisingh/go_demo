package com.tw.go.plugin.util;

import java.util.Map;

public interface FieldValidator {
    public void validate(Map<String, Object> fieldValidation);
}
