#!/usr/bin/env ruby

puts "Deploying Application..."
