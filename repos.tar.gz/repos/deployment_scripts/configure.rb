#!/usr/bin/env ruby

puts "Configuring Application..."
