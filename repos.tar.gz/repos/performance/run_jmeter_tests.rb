#!/usr/bin/env ruby

puts "Jmeter tests for benchmarking"
