#!/usr/bin/env ruby

puts "Standby file to initiate execution of regression tests"
