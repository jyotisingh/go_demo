#!/usr/bin/env ruby

puts "Standby file to initiate execution of user acceptance tests"
