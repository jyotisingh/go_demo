#!/usr/bin/env ruby

puts "Backing up production data..."
sleep 7
puts "Done!"
