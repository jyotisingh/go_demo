#!/usr/bin/env ruby

puts "Pubish artifacts"
